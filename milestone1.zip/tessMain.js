  'use strict';
//import { mat3, mat3d, mat3n, mat4, quat, utils } from '../FinalProject/wgpu-matrix/dist/3.x/wgpu-matrix.module.js';
  // Global variables that are set and used
  // across the application
let verticesSize,
    vertices,
    adapter,
    gl,
    colorAttachment,
    colorTextureView,
    colorTexture,
    depthTexture,
    code,
    computeCode,
    shaderDesc,
    colorState,
    shaderModule,
    pipeline,
    renderPassDesc,
    commandEncoder,
    passEncoder,
    device,
    drawingTop,
    drawingLeft,
    canvas,
    bary,
    points,
    uniformValues,
    uniformDistanceValues,
    uniformBindGroup,
    indices,
    colors;
  
  // buffers
  let myVertexBuffer = null;
  let myBaryBuffer = null;
  let myColorBuffer = null;
  let myIndexBuffer = null;
  let uniformBuffer;
  let uniformDistanceBuffer;

  // Other globals with default values;
  var division1 = 3;
  var division2 = 1;
  var updateDisplay = true;
  var anglesReset = [0.0, 0.0, 0.0, 0.0];
  var angles = [0.0, 0.0, 0.0, 0.0];
  var distance = [0.0, 0.0, 0.0, 0.0];
  var angleInc = 5.0;
  var distanceInc = 0.05;
  
  // Shapes we can draw
  var CUBE = 1;
  var CYLINDER = 2;
  var CONE = 3;
  var COMPUTECUBE = 4;
  var curShape = CUBE;

// set up the shader var's
function setShaderInfo() {
    // set up the shader code var's
    code = document.getElementById('shader').innerText;
    shaderDesc = { code: code };
    shaderModule = device.createShaderModule(shaderDesc);
    colorState = {
        format: 'bgra8unorm'
    };

    // set up depth
    // depth shading will be needed for 3d objects in the future
    depthTexture = device.createTexture({
        size: [canvas.width, canvas.height],
        format: 'depth24plus',
        usage: GPUTextureUsage.RENDER_ATTACHMENT,
    });
}

  // Create a program with the appropriate vertex and fragment shaders
  async function initProgram() {

      // Check to see if WebGPU can run
      if (!navigator.gpu) {
          console.error("WebGPU not supported on this browser.");
          return;
      }

      // get webgpu browser software layer for graphics device
      adapter = await navigator.gpu.requestAdapter();
      if (!adapter) {
          console.error("No appropriate GPUAdapter found.");
          return;
      }

      // get the instantiation of webgpu on this device
      device = await adapter.requestDevice();
      if (!device) {
          console.error("Failed to request Device.");
          return;
      }

      // configure the canvas
      gl = canvas.getContext('webgpu');
      const canvasConfig = {
          device: device,
          // format is the pixel format
          format: navigator.gpu.getPreferredCanvasFormat(),
          // usage is set up for rendering to the canvas
          usage:
              GPUTextureUsage.RENDER_ATTACHMENT,
          alphaMode: 'opaque'
      };
      gl.configure(canvasConfig);
  }

  // general call to make and bind a new object based on current
  // settings..Basically a call to shape specfic calls in cgIshape.js
async function createNewShape() {

    console.log("inside create new shape: " + curShape);
    // Call the functions in an appropriate order
    setShaderInfo();

    // clear your points and elements
    points = [];
    indices = [];
    bary = [];
    colors = [];
    
    // make your shape based on type
    if (curShape == CUBE) makeCube(division1);
    else if (curShape == CYLINDER) makeCylinder([0, 0, 0], [0, 0, 0], division1, division2);
    else if (curShape == CONE) makeCone(division1, division2);
    else if (curShape == COMPUTECUBE) makeComputeCube(division1);
    else
        console.error(`Bad object type`);

    createPipeline();
}

async function createPipeline()
{
    // create and bind vertex buffer

    // set up the attribute we'll use for the vertices
    const vertexAttribDesc = {
        shaderLocation: 0, // @location(0) in vertex shader
        offset: 0,
        format: 'float32x3' // 3 floats: x,y,z
    };

    // this sets up our buffer layout
    const vertexBufferLayoutDesc = {
        attributes: [vertexAttribDesc],
        arrayStride: Float32Array.BYTES_PER_ELEMENT * 3, // sizeof(float) * 3 floats
        stepMode: 'vertex'
    };

    // buffer layout and filling
    const vertexBufferDesc = {
        size: points.length * Float32Array.BYTES_PER_ELEMENT,
        usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST,
        mappedAtCreation: true
    };
    myVertexBuffer = device.createBuffer(vertexBufferDesc);
    let writeArray =
        new Float32Array(myVertexBuffer.getMappedRange());

    writeArray.set(points); // this copies the buffer
    myVertexBuffer.unmap();

    // create and bind bary buffer
    const baryAttribDesc = {
        shaderLocation: 1, // @location(1) in vertex shader
        offset: 0,
        format: 'float32x3' // 3 floats: x,y,z
    };

    // this sets up our buffer layout
    const myBaryBufferLayoutDesc = {
        attributes: [baryAttribDesc],
        arrayStride: Float32Array.BYTES_PER_ELEMENT * 3, // 3 bary's
        stepMode: 'vertex'
    };

    // buffer layout and filling
    const myBaryBufferDesc = {
        size: bary.length * Float32Array.BYTES_PER_ELEMENT,
        usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST,
        mappedAtCreation: true
    };
    myBaryBuffer = device.createBuffer(myBaryBufferDesc);
    let writeBaryArray =
        new Float32Array(myBaryBuffer.getMappedRange());

    writeBaryArray.set(bary); // this copies the buffer
    myBaryBuffer.unmap();


    //COLOR BUFFER
    // create and bind color buffer
    const colorAttribDesc = {
        shaderLocation: 2, // @location(1) in vertex shader
        offset: 0,
        format: 'float32x3' // 3 floats: r,g,b,a
    };

    // this sets up our buffer layout
    const myColorBufferLayoutDesc = {
        attributes: [colorAttribDesc],
        arrayStride: Float32Array.BYTES_PER_ELEMENT * 3, // 3 
        stepMode: 'vertex'
    };

    // buffer layout and filling
    const myColorBufferDesc = {
        size: colors.length * Float32Array.BYTES_PER_ELEMENT,
        usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST,
        mappedAtCreation: true
    };
    myColorBuffer = device.createBuffer(myColorBufferDesc);
    let writeColorArray =
        new Float32Array(myColorBuffer.getMappedRange());

    writeColorArray.set(colors); // this copies the buffer
    myColorBuffer.unmap();

    // setup index buffer

    // first guarantee our mapped range is a multiple of 4
    // mainly necessary becauses uint16 is only 2 and not 4 bytes
    if (indices.length % 2 != 0) {
        indices.push(indices[indices.length - 1]);
    }
    const myIndexBufferDesc = {
        size: indices.length * Uint16Array.BYTES_PER_ELEMENT,
        usage: GPUBufferUsage.INDEX | GPUBufferUsage.COPY_DST,
        mappedAtCreation: true
    };
    myIndexBuffer = device.createBuffer(myIndexBufferDesc);
    let writeIndexArray =
        new Uint16Array(myIndexBuffer.getMappedRange());

    writeIndexArray.set(indices); // this copies the buffer
    myIndexBuffer.unmap();

    // Set up the uniform var
    let uniformBindGroupLayout = device.createBindGroupLayout({
        entries: [
            {
                binding: 0,
                visibility: GPUShaderStage.VERTEX,
                buffer: {},
            },
            {
                binding: 1,
                visibility: GPUShaderStage.VERTEX,
                buffer: {}
            }
        ]
    });

    // set up the pipeline layout
    const pipelineLayoutDesc = { bindGroupLayouts: [uniformBindGroupLayout] };
    const layout = device.createPipelineLayout(pipelineLayoutDesc);

    // pipeline desc
    const pipelineDesc = {
        layout,
        vertex: {
            module: shaderModule,
            entryPoint: 'vs_main',
            buffers: [vertexBufferLayoutDesc, myBaryBufferLayoutDesc, myColorBufferLayoutDesc]
        },
        fragment: {
            module: shaderModule,
            entryPoint: 'fs_main',
            targets: [colorState]
        },
        depthStencil: {
            depthWriteEnabled: true,
            depthCompare: 'less',
            format: 'depth24plus',
        },
        primitive: {
            topology: 'triangle-list', //<- MUST change to draw lines! 
            frontFace: 'cw', // this doesn't matter for lines
            cullMode: 'back'
        }
    };

    pipeline = device.createRenderPipeline(pipelineDesc);

    uniformValues = new Float32Array(angles);
    uniformDistanceValues = new Float32Array(distance);

    uniformBuffer = device.createBuffer({
        size: uniformValues.byteLength,
        usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
    });
    uniformDistanceBuffer = device.createBuffer({
        size: uniformDistanceValues.byteLength,
        usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
    });
    // copy the values from JavaScript to the GPU
    device.queue.writeBuffer(uniformBuffer, 0, uniformValues);
    device.queue.writeBuffer(uniformDistanceBuffer, 0, uniformDistanceValues);

    uniformBindGroup = device.createBindGroup({
        layout: pipeline.getBindGroupLayout(0),
        entries: [
            {
                binding: 0,
                resource: { buffer: uniformBuffer },

            },
            {
                binding: 1,
                resource: { buffer: uniformDistanceBuffer },
            },
        ],
    });

    const bindGroupLayout = device.createBindGroupLayout({
        entries: [
            {
                binding: 0,
                visibility: GPUShaderStage.FRAGMENT,
                sampler: {
                    type: 'non-filtering',
                },
            },
            {
                binding: 1,
                visibility: GPUShaderStage.FRAGMENT,
                texture: {
                    sampleType: 'unfilterable-float',
                    viewDimension: '2d',
                    multisampled: false,
                },
            },
        ],
    });

    // indicate a redraw is required.
    updateDisplay = true;
}

// general call to make and bind a new object based on current
// settings..Basically a call to shape specfic calls in cgIshape.js
async function createHillGarden() {

    console.log("inside create new shape: " + curShape);
    // Call the functions in an appropriate order
    setShaderInfo();

    // clear your points and elements
    points = [];
    indices = [];
    bary = [];
    colors = [];

    makeHillGarden();

    // create and bind vertex buffer

    createPipeline();
}

// We call draw to render to our canvas
function draw() {
    //console.log("inside draw");
    //console.log("angles: " + angles[0] + " " +angles[1] + " " + angles[2]);

    // set up color info
    colorTexture = gl.getCurrentTexture();
    colorTextureView = colorTexture.createView();
    

    // a color attachment ia like a buffer to hold color info
    colorAttachment = {
        view: colorTextureView,
        clearValue: { r: 0.6, g: 0.8, b: 1.0, a: 1 },
        loadOp: 'clear',
        storeOp: 'store'
    };

    renderPassDesc = {
        colorAttachments: [colorAttachment],
        depthStencilAttachment: {
            view: depthTexture.createView(),
            depthClearValue: 1.0,
            depthLoadOp: 'clear',
            depthStoreOp: 'store',
        },
    };

    // convert to radians before sending to shader
    uniformValues[0] = radians(angles[0]);
    uniformValues[1] = radians(angles[1]);
    uniformValues[2] = radians(angles[2]);
    uniformDistanceValues[0] = distance[0];
    uniformDistanceValues[1] = distance[1];
    uniformDistanceValues[2] = distance[2];

    // copy the values from JavaScript to the GPU
    device.queue.writeBuffer(uniformBuffer, 0, uniformValues);
    device.queue.writeBuffer(uniformDistanceBuffer, 0, uniformDistanceValues);

    // create the render pass
    commandEncoder = device.createCommandEncoder();
    passEncoder = commandEncoder.beginRenderPass(renderPassDesc);
    passEncoder.setViewport(0, 0,canvas.width, canvas.height, 0, 1);
    passEncoder.setPipeline(pipeline);
    passEncoder.setBindGroup(0, uniformBindGroup);
    passEncoder.setVertexBuffer(0, myVertexBuffer);
    passEncoder.setVertexBuffer(1, myBaryBuffer);
    passEncoder.setVertexBuffer(2, myColorBuffer);
    passEncoder.setIndexBuffer(myIndexBuffer, "uint16");
    passEncoder.drawIndexed(indices.length, 1);
    passEncoder.end();

    // submit the pass to the device
    device.queue.submit([commandEncoder.finish()]);
}

function update() {
    draw();
    createHillGarden();
}

function advanceSeason() {
    season = (season + 0.005) % 1;
}

  // Entry point to our application
async function init() {
    // Retrieve the canvas
    canvas = document.querySelector("canvas");

    // deal with keypress
    window.addEventListener('keydown', gotKey, false);

    // Read, compile, and link your shaders
    await initProgram();

    initHillGarden();

    // create and bind your current object
    createHillGarden();

    // do a draw
    draw();
}

async function initHillGarden() {
    //init all the trees
    trees = [];
    var n = Math.round(Math.random() * maxTrees);
    //TODO delete
    n = 1;
    for (var i = 0; i < n; i++) {
        initTree();
    }
    console.log(trees);
}

async function initTree() {
    var x = 0; var z = 0;
    var y = hillHeight / 2 - 0.1 + hillOriginY;
    var origin = [x, y, z];

    var treeHeight = 0.8*Math.random() + 0.1;
    var branchCount = Math.round(Math.random()*5);
    var trunkHeight = Math.random() * 0.2;
    var diameter = Math.random() * 0.03 + 0.08;

    var seasonColor = valueToColor(season);
    var barkColor = [0.8, 0.4, 0.2];
    var color = barkColor;
    color = color.map((c, i) => c + 0.3 * (seasonColor[i] - c));
    var tree = new Tree(origin, trunkHeight, treeHeight, color, branchCount, diameter);

    trees.push(tree);
}