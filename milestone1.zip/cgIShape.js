//
// fill in code that creates the triangles for a cube with dimensions 0.5x0.5x0.5
// on each side (and the origin in the center of the cube). with an equal
// number of subdivisions along each cube face as given by the parameter
//subdivisions
//

let rowRadiusLst = [0.0];
var hillHeight = 2.5;
var hillDiameter = 5.0;
var hillOriginY = -1.5;

var season = 0.3;

var maxTrees = 10;

class Tree {
    constructor(origin, trunkHeight, height, color, branchCount, diameter) {
        this.origin = origin;
        this.trunkHeight = trunkHeight;
        this.height = height;
        this.color = color;
        this.branchCount = branchCount;
        this.diameter = diameter;
    }
}

var trees;

function makeCube (subdivisions)  {
    
    // fill in your code here.
    // delete the code below first.
    // NOTE: your triangles need to be clockwise for the 
    // pipeline not to cull them!

    var width = 0.5;

    //front face
    drawCubeFace([-0.25, -0.25, -0.25], width, width, 0, subdivisions)
    //draw back face
    drawCubeFace([width / 2, -0.25, width/2], -width, width, 0, subdivisions);

    //draw left face
    drawCubeFace([-0.25, -0.25, width/2], 0, width, -width, subdivisions);
    //right face
    drawCubeFace([width/2, -0.25, -0.25], 0, width, width, subdivisions)

    //draw top face
    drawCubeFace([-0.25, width / 2, -0.25], width, 0, width, subdivisions);
    //draw bottom face
    drawCubeFace([-0.25, -0.25, width/2], width, 0, -width, subdivisions);

    //drawSquarePolygon([0, width, 0], width, 0, width);

   /* addTriangle(0, width, 0,
        0, width, width,
        width, width, width);    */
    //drawCubeFace([0, 0, 0], xChange, yChange, zChange);

    ////do front face
    //originCoord = [0, 0, 0];
    //drawCubeFace(originCoord, width, width, 0);

}

// draw a whole cube face
function drawCubeFace(originCoord, xChange, yChange, zChange, subdivisions) {
    polyOriginCoord = [0, 0, 0];
    for (var r = 0; r < subdivisions; r++) {
        for (var c = 0; c < subdivisions; c++) {
            if (yChange == 0) {
                polyOriginCoord = [originCoord[0] + r * xChange / subdivisions, originCoord[1] + c * yChange / subdivisions, originCoord[2] + c * zChange / subdivisions];
            }
            else if (xChange == 0) {
                polyOriginCoord = [originCoord[0] + r * xChange / subdivisions, originCoord[1] + c * yChange / subdivisions, originCoord[2] + r * zChange / subdivisions];
            }
            else {
                polyOriginCoord = [originCoord[0] + r * xChange / subdivisions, originCoord[1] + c * yChange / subdivisions, originCoord[2] + r * zChange / subdivisions];
            }
            drawSquarePolygon(polyOriginCoord, xChange / subdivisions, yChange / subdivisions, zChange / subdivisions);
        }
    }
}

//draw a column of cylinder faces
function drawCylinderFace(originCoord, xChange, yChange, zChange, subdivisions, color = [1, 0, 0]) {
    polyOriginCoord = [0, 0, 0];
    for (var c = 0; c < subdivisions; c++) {
        if (xChange == 0) {
            polyOriginCoord = [originCoord[0], originCoord[1] + c * yChange / subdivisions, originCoord[2]];
        }
        else {
            polyOriginCoord = [originCoord[0], originCoord[1] + c * yChange / subdivisions, originCoord[2]];
        }
        drawSquarePolygon(polyOriginCoord, xChange, yChange / subdivisions, zChange, color);
    }
}

//draw two triangles to create a single square shape
function drawSquarePolygon(originCoord, xChange, yChange, zChange, color = [1, 0, 0]) {
    xOrigin = originCoord[0];
    yOrigin = originCoord[1];
    zOrigin = originCoord[2];

    if (yChange != 0) {
        //top triangle
        addTriangle(xOrigin, yOrigin, zOrigin,
            xOrigin, yOrigin + yChange, zOrigin,
            xOrigin + xChange, yOrigin + yChange, zOrigin + zChange,
            color)

        //bottom triangle
        addTriangle(xOrigin, yOrigin, zOrigin,
            xOrigin + xChange, yOrigin + yChange, zOrigin + zChange,
            xOrigin + xChange, yOrigin, zOrigin + zChange,
            color)
    }
    else {
        //top triangle
        addTriangle(xOrigin, yOrigin, zOrigin,
            xOrigin, yOrigin + yChange, zOrigin + zChange,
            xOrigin + xChange, yOrigin + yChange, zOrigin + zChange,
            color)
        //draw bottom triangle
        addTriangle(xOrigin, yOrigin, zOrigin,
            xOrigin + xChange, yOrigin + yChange, zOrigin + zChange,
            xOrigin + xChange, yOrigin, zOrigin,
            color)
    }
}

function makeTree(n) {
    const tree = trees[n];
    //get root point-- slightly under some  point on the hill
    let origin = tree.origin;

    let treeHeight = tree.height;
    let branchCount = tree.branchCount;
    let trunkHeight = tree.trunkHeight;
    let color = tree.color;
    let diameter = tree.diameter;

    //make trunk with a random length
    makeBranch(origin.slice(), [0, 0, 0], diameter, trunkHeight, 15, 2, color, 0, true);
    //make rest of tree w branches
    let treeOrigin = origin.slice();
    treeOrigin.y += tree.trunkHeight / 2;
    makeBranch(treeOrigin, [0, 0, 0], diameter, treeHeight, 15, 2, color, branchCount);
}

//code that creates the triangles for a cylinder with diameter 0.5
// and height of 0.5 (centered at the origin) with the number of subdivisions
// around the base and top of the cylinder (given by radialdivision) and
// the number of subdivisions along the surface of the cylinder given by
//heightdivision.
function makeBranch(origin, angle, diameter, height, radialdivision, heightdivision, color = [1, 0, 0], branchCount, isTrunk = false) {

    //we are given origin of BOTTOM of cylinder, adjust this to be the middle 
    //origin[1] = origin[1] + height / 2;

    //interpolate season and bark color to get seasonal bark! 

    //we are given origin of BOTTOM of cylinder, adjust this to be the middle 
    origin[1] = origin[1] + height / 2;

    //draw top circle
    xRadialPoints = [];
    zRadialPoints = [];
    //TODO fix bug where it randomly grabs other points???
    let topCircleOrigin = origin.slice();
    topCircleOrigin.y += height / 2;
    xRadialPoints, zRadialPoints = drawCircle(topCircleOrigin, radialdivision, diameter, false, color);

    //TODO do a transformation on the branches so that they are spitting off at an angle instead of simply being next to them
    //x rotation
    
    for (var i = 0; i < radialdivision; i++) {
        drawCylinderFace(
            [xRadialPoints[i] + origin[0], -height / 2 + origin[1], zRadialPoints[i] + origin[2]],
            xRadialPoints[(i + 1) % radialdivision] - xRadialPoints[i],
            height,
            zRadialPoints[(i + 1) % radialdivision] - zRadialPoints[i],
            heightdivision,
            color);
    }

    drawCircle([origin[0], -height / 2 + origin[1], origin[2]], radialdivision, diameter, true, color);

    if (branchCount > 0) {
        var newDiameter = diameter / 2;
        var newOrigin = [origin[0] - newDiameter/2 - diameter/4, origin[1] + height / 2, origin[2]];
        //TODO: add to new origin w/ unit vector of angle * height
        var newHeight = height / 2;
        var newAngle = angle;
        branchCount = branchCount - 1;
        makeBranch(newOrigin, newAngle, newDiameter, newHeight, radialdivision, heightdivision, color, branchCount);
        var rightOrigin = [origin[0] + newDiameter / 4 + diameter / 4, origin[1] + height / 2, origin[2]];
        makeBranch(rightOrigin, newAngle, newDiameter, newHeight, radialdivision, heightdivision, color, branchCount);
    }
    else if (!isTrunk){
        newOrigin = origin;
        newOrigin.x -= leafDiameter / 2 - diameter / 2;
        newOrigin[1] += height/2;
        var leafDiameter = 3*diameter;
        makeLeaf(newOrigin, leafDiameter);
    }
}

//code that creates the triangles for a cylinder with diameter 0.5
// and height of 0.5 (centered at the origin) with the number of subdivisions
// around the base and top of the cylinder (given by radialdivision) and
// the number of subdivisions along the surface of the cylinder given by
//heightdivision.
function makeCylinder (origin, angle, diameter, height, radialdivision, heightdivision){

    //we are given origin of BOTTOM of cylinder, adjust this to be the middle 
    origin[1] = origin[1] + height / 2;

    //draw top circle
    xRadialPoints = [];
    zRadialPoints = [];
    xRadialPoints, zRadialPoints = drawCircle([origin[0], height/2 + origin[1], origin[2]], radialdivision, diameter, false);

    //drawCubeFace([xRadialPoints[0], 0, zRadialPoints[0]], xRadialPoints[radialdivision-1] - xRadialPoints[0], height, zRadialPoints[radialdivision-1] - zRadialPoints[0], heightdivision);
    //drawCubeFace([xRadialPoints[radialdivision-1], 0, zRadialPoints[radialdivision-1]], xRadialPoints[0] - xRadialPoints[radialdivision-1], height, zRadialPoints[0] - zRadialPoints[radialdivision-1], heightdivision);
    for (var i = 0; i < radialdivision; i++) {
        drawCylinderFace(
            [xRadialPoints[i] + origin[0], -height / 2 + origin[1], zRadialPoints[i] + origin[2]],
            xRadialPoints[(i + 1) % radialdivision] - xRadialPoints[i],
            height,
            zRadialPoints[(i + 1) % radialdivision] - zRadialPoints[i],
            heightdivision);
    }

    drawCircle([origin[0], -height / 2 + origin[1], origin[2]], radialdivision, diameter, true);
}

//TODO tie the color of the leaves to the individual season in some way
function makeLeaf(origin, diameter, color) {

    //generate color based on season
    //if season between 0.85 and 0.95, dont draw
    if (season > 0.65 && season < 1) {
        return;
    }
    if (season < 0.3) {
        diameter = diameter * (season/0.3);
    }
    color = valueToColor(season);
    color[1] += 0.3;

    xRadialPoints = [];
    yRadialPoints = [];

    radialdivision = 10;

    radius = diameter;

    for (var i = 0; i < radialdivision; i++) {
        x = radius * Math.cos(i * 2 * (Math.PI / radialdivision));
        y = radius * Math.sin(i * 2 * (Math.PI / radialdivision));
        xRadialPoints[i] = x;
        yRadialPoints[i] = y;
    }
    addTriangle(origin[0], origin[1], origin[2],
        xRadialPoints[xRadialPoints.length - 1] + origin[0], origin[1] + yRadialPoints[yRadialPoints.length - 1], origin[2],
        xRadialPoints[0] + origin[0], origin[1] + yRadialPoints[0], origin[2],
        color);
    addTriangle(origin[0], origin[1], origin[2],
        xRadialPoints[0] + origin[0], origin[1] + yRadialPoints[0], origin[2],
        xRadialPoints[xRadialPoints.length - 1] + origin[0], origin[1] + yRadialPoints[yRadialPoints.length-1], origin[2],
        color);
    

    for (var i = 0; i < xRadialPoints.length - 1; i++) {
        addTriangle(origin[0], origin[1], origin[2],
            xRadialPoints[i] + origin[0], origin[1] + yRadialPoints[i], origin[2],
            xRadialPoints[i + 1] + origin[0], origin[1] + yRadialPoints[i + 1], origin[2],
            color);

        addTriangle(origin[0], origin[1], origin[2],
            xRadialPoints[i + 1] + origin[0], origin[1] + yRadialPoints[i + 1], origin[2],
            xRadialPoints[i] + origin[0], origin[1] + yRadialPoints[i], origin[2],
            color);
        
    }
}
function drawCircle(origin, radialdivision, diameter, clockwise, color = [1, 0, 0]) {
    var radius = diameter / 2;

    xRadialPoints = [];
    zRadialPoints = [];

    for (var i = 0; i < radialdivision; i++) {
        x = radius * Math.cos(i * 2 * (Math.PI / radialdivision));
        z = radius * Math.sin(i * 2 * (Math.PI / radialdivision));
        xRadialPoints[i] = x;
        zRadialPoints[i] = z;
    }

    if (clockwise) {
        addTriangle(origin[0], origin[1], origin[2],
            xRadialPoints[xRadialPoints.length - 1] + origin[0], origin[1], zRadialPoints[zRadialPoints.length - 1] + origin[2],
            xRadialPoints[0] + origin[0], origin[1], zRadialPoints[0] + origin[2],
            color);
    }
    else {
        addTriangle(origin[0], origin[1], origin[2],
            xRadialPoints[0] + origin[0], origin[1], zRadialPoints[0] + origin[2],
            xRadialPoints[xRadialPoints.length - 1] + origin[0], origin[1], zRadialPoints[zRadialPoints.length - 1] + origin[2],
            color);
    }

    for (var i = 0; i < xRadialPoints.length - 1; i++) {
        if (clockwise) {
            addTriangle(origin[0], origin[1], origin[2],
                xRadialPoints[i] + origin[0], origin[1], origin[2] + zRadialPoints[i],
                xRadialPoints[i + 1] + origin[0], origin[1], origin[2] + zRadialPoints[i + 1],
                color);
        }
        else {
            addTriangle(origin[0], origin[1], origin[2],
                xRadialPoints[i + 1] + origin[0], origin[1], origin[2] + zRadialPoints[i + 1],
                xRadialPoints[i] + origin[0], origin[1], origin[2] + zRadialPoints[i],
                color);
        }
    }
    return xRadialPoints, zRadialPoints;
}

function drawConePoint(origin, radialdivision, diameter, height, color = [1, 0, 0]) {
    var radius = diameter / 2;

    xRadialPoints = [];
    zRadialPoints = [];

    for (var i = 0; i < radialdivision; i++) {
        x = radius * Math.cos(i * 2 * (Math.PI / radialdivision));
        z = radius * Math.sin(i * 2 * (Math.PI / radialdivision));
        xRadialPoints[i] = x;
        zRadialPoints[i] = z;
    }

    addTriangle(
        xRadialPoints[xRadialPoints.length - 1] + origin[0], origin[1], zRadialPoints[zRadialPoints.length - 1] + origin[2],
        origin[0], origin[1] + height, origin[2],
        xRadialPoints[0] + origin[0], origin[1], zRadialPoints[0] + origin[2],
        color);

    for (var i = 0; i < xRadialPoints.length - 1; i++) {
        addTriangle(
            xRadialPoints[i] + origin[0], origin[1], origin[2] + zRadialPoints[i],
            origin[0], origin[1] + height, origin[2],
            xRadialPoints[i + 1] + origin[0], origin[1], origin[2] + zRadialPoints[i + 1],
            color);
    }

    return xRadialPoints, zRadialPoints;
}

function drawHillColumn(topLeft, topRight, innerAngle, height, heightdivision, radialdivision, columnNumber, rowNumber, color = [1, 0, 0]) {

    //to calc bottom right and left points, use inner angle and row height
    //height = topleft[1] + rowHeight
    // bottom x and z can

    var rowHeight = height / heightdivision;

    //bottom right x and z 
    bottomLeftY = topLeft[1] + rowHeight;

    rowRadius = rowRadiusLst[rowNumber];

    let leftTheta = (columnNumber + 1) * 2 * (Math.PI / radialdivision);
    let rightTheta = columnNumber * 2 * (Math.PI / radialdivision);

    var bottomRightX = rowRadius * Math.cos(leftTheta);
    var bottomRightZ = rowRadius * Math.sin(leftTheta);

    //top triangle
    addTriangle(
        topRight[0], topRight[1], topRight[2],
        topLeft[0], topLeft[1], topLeft[2],
        bottomRightX, topLeft[1] - rowHeight, bottomRightZ,
        color);

    //bottom triangle 
    var bottomLeftX = rowRadius * Math.cos(rightTheta);
    var bottomLeftZ = rowRadius * Math.sin(rightTheta);
    addTriangle(
        bottomLeftX, topLeft[1] - rowHeight, bottomLeftZ,
        topRight[0], topRight[1], topRight[2],
        bottomRightX, topRight[1] - rowHeight, bottomRightZ,
        color);

    //check if should recurse
    if (rowNumber != heightdivision - 1) {
        drawHillColumn([bottomRightX, topLeft[1] - rowHeight, bottomRightZ], [bottomLeftX, topLeft[1] - rowHeight, bottomLeftZ], innerAngle, height, heightdivision, radialdivision, columnNumber, rowNumber + 1, color);
    }
}


function drawConeColumn(topLeft, topRight, innerAngle, height, heightdivision, radialdivision, columnNumber, rowNumber) {

    //to calc bottom right and left points, use inner angle and row height
    //height = topleft[1] + rowHeight
    // bottom x and z can

    var rowHeight = height / heightdivision;

    //bottom right x and z 
    bottomLeftY = topLeft[1] + rowHeight;

    rowRadius = (height/2 - (topLeft[1] - rowHeight)) * Math.tan((innerAngle)); //r = h * tan(x)

    let leftTheta = (columnNumber + 1) * 2 * (Math.PI / radialdivision);
    let rightTheta = columnNumber * 2 * (Math.PI / radialdivision);

    var bottomRightX = rowRadius * Math.cos(leftTheta);
    var bottomRightZ = rowRadius * Math.sin(leftTheta);

    //top triangle
    addTriangle(topLeft[0], topLeft[1], topLeft[2],
        topRight[0], topRight[1], topRight[2],
        bottomRightX, topLeft[1] - rowHeight, bottomRightZ);

    //bottom triangle 
    var bottomLeftX = rowRadius * Math.cos(rightTheta);
    var bottomLeftZ = rowRadius * Math.sin(rightTheta);
    addTriangle(topRight[0], topRight[1], topRight[2],
        bottomLeftX, topLeft[1] - rowHeight, bottomLeftZ,
        bottomRightX, topRight[1] - rowHeight, bottomRightZ);   

    //check if should recurse
    if (rowNumber != heightdivision -1) {
        drawConeColumn([bottomRightX, topLeft[1] - rowHeight, bottomRightZ], [bottomLeftX, topLeft[1] - rowHeight, bottomLeftZ], innerAngle, height, heightdivision, radialdivision, columnNumber, rowNumber + 1);
    }

}

//
// creates the triangles for a cone with diameter 0.5
// and height of 0.5 (centered at the origin) with the number of
// subdivisions around the base of the cone (given by radialdivision)
// and the number of subdivisions along the surface of the cone
//given by heightdivision.
//
function makeCone (radialdivision, heightdivision) {
    diameter = 0.5;
    height = 0.5;
    radius = diameter / 2;

    xRadialPoints = [];
    zRadialPoints = [];

    if (heightdivision <= 1) {
        xRadialPoints, zRadialPoints = drawConePoint([0, -height/2, 0], radialdivision, diameter, height);
        drawCircle([0, -height/2, 0], radialdivision, diameter, false);
        return;
    }

    innerAngle = Math.atan(radius / height);
    console.log("inner angle : " + innerAngle);

    rowHeight = height / heightdivision;

    rowY = height / 2 - rowHeight;
    rowRadius = rowHeight * Math.tan(innerAngle); //r = h * tan(x)
    xRadialPoints, zRadialPoints = drawConePoint([0, height / 2 - rowHeight, 0], radialdivision, rowRadius * 2, rowHeight);

    ////draw a cone row 
    //for (var i = 0; i < radialdivision; i++) {
    //    rowY = height / 2 - rowHeight * i;
    //    rowRadius = rowHeight * i * Math.tan(innerAngle); //r = h * tan(x)
    //    drawSquarePolygon([xRadialPoints[i], rowY, zRadialPoints[i]], xRadialPoints[i] - xRadialPoints[(i + 1) % radialdivision], rowY, zRadialPoints[i] - zRadialPoints[(i + 1) % radialdivision])
    //}

    for (var i = 0; i < radialdivision; i++) {
        rowY = height / 2 - rowHeight;
        const topLeft = [xRadialPoints[(i + 1) % radialdivision], rowY, zRadialPoints[(i + 1) % radialdivision]];
        const topRight = [xRadialPoints[i], rowY, zRadialPoints[i]];
        drawConeColumn(topLeft, topRight, innerAngle, height, heightdivision, radialdivision, i, 1);
    }

    drawCircle([0, -height / 2, 0], radialdivision, diameter, false);

}

function makeHill(radialdivision, heightdivision) {
    var diameter = hillDiameter;
    var height = hillHeight;
    
    radius = diameter / 2;

    xRadialPoints = [];
    zRadialPoints = [];

    var color = valueToColor(season + Math.random() * 0.05);

    if (heightdivision <= 1) {
        xRadialPoints, zRadialPoints = drawConePoint([0, -height / 2, 0], radialdivision, diameter, height, color);
        drawCircle([0, -height / 2, 0], radialdivision, diameter, true, color);
        return;
    }

    innerAngle = Math.atan(radius / height);

    rowHeight = height / heightdivision;

    rowY = height / 2 - rowHeight;
    rowRadius = rowHeight * Math.tan(innerAngle); //r = h * tan(x)
    xRadialPoints, zRadialPoints = drawConePoint([0, height / 2 - rowHeight + hillOriginY, 0], radialdivision, rowRadius * 2, rowHeight, color);

    //gen rowRadiusLst if needs to be 
    if (rowRadiusLst[0] == [0.0]) {
        rowRadiusLst = [];
        for (var i = 0; i < heightdivision; i++) {
            var rad = 0;
            if (i == 0) {
                rad = (height / 2 - (rowY - rowHeight * (i))) * Math.tan((innerAngle));
            }
            else {
                rad = rowRadiusLst[i - 1];
            }
            if (i < 6) {
                rad = Math.random() * (rad * 1.5) + rad;
                rad = Math.min(rad, diameter / 2 * ((i + 1) / heightdivision))
            }
            else {
                rad = Math.random() * (rad * 0.1) + rad;
                rad = Math.min(rad, diameter/2*((i+1)/heightdivision))
            }
            
            rowRadiusLst[i] = rad;
        }
    }

    for (var i = 0; i < radialdivision; i++) {
        rowY = height / 2 - rowHeight + hillOriginY;
        const topLeft = [xRadialPoints[(i + 1) % radialdivision], rowY, zRadialPoints[(i + 1) % radialdivision]];
        const topRight = [xRadialPoints[i], rowY, zRadialPoints[i]];
        drawHillColumn(topLeft, topRight, innerAngle, height, heightdivision, radialdivision, i, 1, color);
    }

}

function radians(degrees)
{
  var pi = Math.PI;
  return degrees * (pi/180);
}

function addTriangle (x0,y0,z0,x1,y1,z1,x2,y2,z2, color = [0.2, 0.7, 0.5]) {

    
    var nverts = points.length / 3;
    
    // push first vertex
    points.push(x0);  bary.push (1.0);
    points.push(y0);  bary.push (0.0);
    points.push(z0);  bary.push (0.0);
    indices.push(nverts);
    nverts++;

    colors.push(color[0]);
    colors.push(color[1]);
    colors.push(color[2]);
    
    // push second vertex
    points.push(x1); bary.push (0.0);
    points.push(y1); bary.push (1.0);
    points.push(z1); bary.push (0.0);
    indices.push(nverts);
    nverts++

    colors.push(color[0]);
    colors.push(color[1]);
    colors.push(color[2]);
    
    // push third vertex
    points.push(x2); bary.push (0.0);
    points.push(y2); bary.push (0.0);
    points.push(z2); bary.push (1.0);
    indices.push(nverts);
    nverts++;

    colors.push(color[0]);
    colors.push(color[1]);
    colors.push(color[2]);
}


function valueToColor(value) {
    // Ensure the value is clamped between 0 and 1
    value = Math.max(0, Math.min(1, value));

    // Define the color stops: [value, [r, g, b]]
    const colorStops = [
        [0, [0.2, 0.7, 0.4]],    // Bright green at 0.125
        [0.375, [0, 0.3, 0]],  // Dark green at 0.375
        [0.625, [0.5, 0.2, 0]],// Rust color at 0.625
        [0.875, [0.7, 0.9, 1]],// Pale blue at 0.875
        [1, [0.2, 0.7, 0.4]]         // bright green
    ];

    // Find the two stops the value is between
    let lowerStop = colorStops[0];
    let upperStop = colorStops[colorStops.length - 1];

    for (let i = 0; i < colorStops.length - 1; i++) {
        if (value >= colorStops[i][0] && value <= colorStops[i + 1][0]) {
            lowerStop = colorStops[i];
            upperStop = colorStops[i + 1];
            break;
        }
    }

    // Interpolate between the two stops
    const t = (value - lowerStop[0]) / (upperStop[0] - lowerStop[0]);
    const color = lowerStop[1].map((c, i) => c + t * (upperStop[1][i] - c));

    return color;
}

function makeHillGarden() {
    makeHill(30, 30);

    for (var i = 0; i < trees.length; i++) {
        makeTree(i);
    }
}

function translate(pos, x, y, z) {
    pos.x += x;
    pos.y += y;
    pos.z += z;
    return pos;
}

function rotateX(x, y, z, theta) {
    const rad = theta * (Math.PI / 180); // Convert theta to radians
    const xNew = x;
    const yNew = y * Math.cos(rad) - z * Math.sin(rad);
    const zNew = y * Math.sin(rad) + z * Math.cos(rad);

    return [xNew, yNew, zNew];
}

function rotateY(x, y, z, theta) {
    const rad = theta * (Math.PI / 180); // Convert theta to radians
    const xNew = x * Math.cos(rad) + z * Math.sin(rad);
    const yNew = y;
    const zNew = -x * Math.sin(rad) + z * Math.cos(rad);

    return [xNew, yNew, zNew];
}


function rotateZ(x, y, z, theta) {
    const rad = theta * (Math.PI / 180); // Convert theta to radians
    const xNew = x * Math.cos(rad) - y * Math.sin(rad);
    const yNew = x * Math.sin(rad) + y * Math.cos(rad);
    const zNew = z;

    return [xNew, yNew, zNew];
}